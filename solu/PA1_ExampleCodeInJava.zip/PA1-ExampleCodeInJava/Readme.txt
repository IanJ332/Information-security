Code example for Programming Assignment 1. 
Language used: Java. Used feature in Java 15, so you need at least Java 15 environment to run without modifying the code.
Disclaimer: I'm not a good programmer so this is just FYI. And since it's for self-using only, all programs do not have input validations, clear prompt, etc.
(And, they seem long because I like to put long comments...As you can see the comments are longer than the actual code LOL.)
==========
1. SimpleSubstitution.java
Use English letter frequency to decrypt a simple substitution cipher. The key point is, you can't count only on the frequency. Also need extra analyze. So, as the question suggested, allow user to try multiple time, and display the corresponding result with the guessed key. Option 2 is what you are asked to do. Option 1 & 3 just FYI. 
==========
2. A51.java
Generate keystream based on X,Y,Z. Simple, just follow the algorithm. Note the order of each step. And since the question give you X,Y,Z in strings, and ask you to enter result in strings, you can directly play with a string use charAt method. No other data structure needed.
==========
3. RSA.java
Given p, q, e, get the smallest possible d using extended Euclidean algorithm. The hard part is to understand the math. Coding is easy if you understand what you need to do, that is, which coefficient is the resulting d. See code for more details.
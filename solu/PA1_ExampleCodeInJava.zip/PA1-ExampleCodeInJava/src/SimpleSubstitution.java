import java.util.*;

/**
 * A simple program to break a simple substitution cipher by English letter frequency count.
 * Disclaimer: For self-use only, so no input validation, no clear prompts, etc.
 * And, seems need to simplify...still some redundant code, and the workflow is awful...
 *
 * @author Yan Chen
 */
public class SimpleSubstitution {
    // Letter frequency (high to low) from Wikipedia
    private static final String FREQUENCY_ORDER = "etaoinshrdlcumwfgypbvkjxqz";
    private static String key = "abcdefghijklmnopqrstuvwxyz";
    private static String cipher = "";
    private static String plain = "";
    // An array for letters - use array for more concise code
    // And also easy to sort
    // Other options: hash-based data structure can't sort easily;
    // tree-based data structure search not efficient;
    private static Letter[] letters;

    public static void main(String[] args) {
        try (Scanner in = new Scanner(System.in)){
            System.out.println("Enter the ciphertext: ");
            cipher = in.nextLine().toUpperCase();
            cipher = cipher.replace(" ", "");
            plain = cipher;
            setDefaultKey();
            displayStatics();
            do {
                decryptMenu(in);
                System.out.print("Try another way? (y/n): ");
                String input = in.nextLine();
                if (input.startsWith("n")) break;
                reset(); // reset the key & plaintext if continued
            } while (true);
            System.out.println("Bye!");

        } catch (Exception e) {
            System.out.printf("Something wrong: %s\n", e.getMessage());
        }
    }

    /**
     * Set the default key based on the frequency
     */
    private static void setDefaultKey() {
        initialize();
        countFrequency();
        Arrays.sort(letters, Comparator.comparingInt(o -> -o.frequency));
        for (int i = 0; i < 26; i++)
            letters[i].setP(FREQUENCY_ORDER.charAt(i));
    }

    /**
     * Initialize the array that holds the letters in alphabet order.
     */
    private static void initialize() {
        letters = new Letter[26];
        for (int i = 'A'; i <= 'Z'; i++)
            letters[i - 'A'] = new Letter((char) i);
    }

    /**
     * Count the frequency.
     */
    private static void countFrequency() {
        for (int i = 0; i < cipher.length(); i++) {
            int current = cipher.charAt(i) - 'A';
            letters[current].incrementFrequency();
        }
    }

    /**
     * Display the statistics in three ways.
     */
    private static void displayStatics() {
        System.out.println("Resulting statics: \n1. Sort alphabetically based on ciphertext: ");
        printStatistics(Comparator.comparingInt(o -> o.C));
        System.out.println("\n2. Sort alphabetically based on plaintext: ");
        printStatistics(Comparator.comparingInt(o -> o.p));
        System.out.println("\n3. Sort by letter frequency (from high to low): ");
        printStatistics(Comparator.comparingInt(o -> -o.frequency));
    }

    /**
     * Display the statistics based on the required order.
     *
     * @param comparator the way to sort the result
     */
    private static void printStatistics(Comparator<Letter> comparator) {
        if (comparator != null) Arrays.sort(letters, comparator);
        System.out.print("plain:\t");
        for (Letter l : letters) System.out.printf("%s\t", l.p);
        System.out.print("\nCipher:\t");
        for (Letter l : letters) System.out.printf("%s\t", l.C);
        System.out.print("\nCount:\t");
        for (Letter l : letters) System.out.printf("%d\t", l.frequency);
        System.out.println();
    }

    /**
     * Give user 3 choices to choose how to decrypt.
     *
     * @throws Exception for any wrong choice
     */
    private static void decryptMenu(Scanner in) throws Exception {
        System.out.println("""
                ===========================
                How do you want to decrypt the ciphertext?
                1. By default key based on the frequency;
                2. By entering a key;
                3. By changing one by one from the highest frequency.""");
        int choice = in.nextInt();
        in.nextLine(); // So the scanner can read next lines
        switch (choice) {
            case 1 -> decryptByDefault();
            case 2 -> decryptByKey(in);
            case 3 -> decryptOneByOne(in);
            default -> throw new Exception("Wrong input.");
        }
        System.out.printf("Final key: %s\n", key.toUpperCase());
        System.out.printf("Final plaintext: %s\n", plain);
    }

    /**
     * Decrypt using the default key.
     */
    private static void decryptByDefault() {
        for (int i = 0; i < 26; i++) {
            // Key should be ordered by plaintext letter, so replace p with C
            key = key.replace(letters[i].p, letters[i].C);
            plain = plain.replace(letters[i].C, letters[i].p);
        }
    }

    /**
     * Decrypt using a specified key getting from the user.
     * Allow multiple attempts
     *
     * @throws Exception if user enters a key is less than 26 letters long
     */
    private static void decryptByKey(Scanner in) throws Exception {
        do {
            System.out.print("Please enter the key: ");
            key = in.nextLine().toUpperCase(); // make sure it's all uppercase!
            if (key.length() != 26) throw new Exception("Wrong input. ");
            for (int i = 0; i < 26; i++)
                plain = plain.replace(key.charAt(i), (char) (i + 'a'));
            System.out.printf("Plaintext: %s\n", plain);

            System.out.print("Try another key? (y/n): ");
            String input = in.nextLine();
            if (input.startsWith("n")) break;
            reset(); // reset the key & plaintext if continued
        } while (true);
    }

    /**
     * Decrypt the cipher by replacing one letter at one time.
     */
    private static void decryptOneByOne(Scanner in) {
        // Use HashSet for efficient lookups, set initialCapacity to avoid rehashing
        HashSet<Character> substituted = new HashSet<>(26);
        for (int i = 0; i < 26; i++) {
            char C = letters[i].C;
            System.out.print(getSuggestion(substituted, i));
            String input = in.nextLine().toLowerCase();
            if (input.length() > 1) break;
            char p = input.charAt(0);
            plain = plain.replace(C, p);
            substituted.add(p); // keep track of the plaintext recovered
            // Again, remember Key should be ordered by plaintext letter ("opposite" order)
            key = key.replace(p, C);
            System.out.printf("After substitution: \n%s\n", plain);
        }
    }

    /**
     * Get suggestion for the substitution for 1 letter.
     * The best match will be based on the default key,
     * but if the corresponding plaintext already recovered,
     * it will be the first element appear in other possibilities, where
     * other possibilities are those have a frequency different <= 15%
     *
     * @param done A HashSet of plaintext letters that already got recovered
     * @param n    the index of the current letter
     * @return suggestion (best match and other possibilities)
     */
    private static String getSuggestion(HashSet<Character> done, int n) {
        String result = "Substitute " + letters[n].C + " (Best match - ";
        char best = done.contains(letters[n].p) ? '\0' : letters[n].p;
        // ArrayDeque for fast insertion and sequential retrieving
        ArrayDeque<Character> possible = new ArrayDeque<>();
        for (int i = 0; i < 26; i++) {
            // Get percentage difference
            double diff = 1.0 * Math.abs(letters[i].frequency - letters[n].frequency) / cipher.length();
            if (i != n && diff < 0.01 && !done.contains(letters[i].p))
                possible.add(letters[i].p);
        }
        if (best == '\0') best = possible.pop();
        StringBuilder temp = new StringBuilder("): ");
        if (!possible.isEmpty()) {
            temp = new StringBuilder("; other possibilities - ");
            while (!possible.isEmpty())
                temp.append(possible.poll()).append(" / ");
        }
        String others = temp.toString().replaceAll(" / $", "): ");
        return result + best + others;
    }

    private static void reset() {
        plain = cipher;
        key = "abcdefghijklmnopqrstuvwxyz";
    }

    /**
     * A helper class for each letter
     */
    private static class Letter {
        char C; // Ciphertext
        char p; // Corresponding plaintext
        int frequency;

        public Letter(char c) {
            this.C = c;
            this.p = '\0';
            this.frequency = 0;
        }

        /**
         * Used when counting frequency.
         */
        public void incrementFrequency() {
            this.frequency++;
        }

        /**
         * Set the corresponding plaintext letter.
         * Used to get the default key.
         *
         * @param p corresponding plaintext letter based on frequency
         */
        public void setP(char p) {
            this.p = p;
        }
    }
}
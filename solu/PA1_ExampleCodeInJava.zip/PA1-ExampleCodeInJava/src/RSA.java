import java.util.Scanner;

/**
 * Simple program to find possible d for RSA using extended Euclidean algorithm.
 *
 * Disclaimer: For self-use only, so no input validation,
 * no clear prompts, no try-again option, etc.
 *
 * @author Yan Chen
 */
public class RSA {
    public static void main(String[] args) {
        // Get user input for p, q, and e
        int p = get('p');
        int q = get('q');
        int e = get('e');

        int phi = (p - 1) * (q - 1);
        int d = getD(e, phi);
        // Get positive d
        while (d < 0) d += phi;

        System.out.println(d);
    }

    /**
     * Get private key d in RSA by extended Euclidean algorithm.
     *
     * @param x the first number (in this case, e)
     * @param y the second number (in this case, phi(n))
     * @return the Bezout's coefficients of the first number (in this case, d)
     */
    private static int getD(int x, int y) {
        // a for Bezout's coefficients of x
        // g for gcd

        // g0 = x; g1 = y
        int gn_2 = x;
        int gn_1 = y;
        // a0 = 1; a1 = 0;
        int an_2 = 1;
        int an_1 = 0;
        // b not needed in this case

        while (true) {
            // gn = gn-2 mod gn-1
            int gn = gn_2 % gn_1;
            // qn = floor(gn-2/gn-1)
            int q = Math.floorDiv(gn_2, gn_1);
            // an = an-2 – qn * an-1;
            int an = an_2 - q * an_1;

            // update "parameters"
            gn_2 = gn_1;
            gn_1 = gn;

            an_2 = an_1;
            an_1 = an;

            if (gn == 0) break;
        }
        return an_2;
    }

    /**
     * Get parameter from the user.
     *
     * @param c parameter needed
     * @return user input in String
     */
    private static int get(char c) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("Enter %s: ", c);
        return scanner.nextInt();
    }

}
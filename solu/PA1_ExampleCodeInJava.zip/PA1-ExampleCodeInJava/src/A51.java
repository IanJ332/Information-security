import java.util.Scanner;

/**
 * Simple program to generate bits using A5/1 cipher.
 * Disclaimer: For self-use only, so no input validation,
 * no clear prompts, no try-again option, etc.
 *
 * @author Yan Chen
 */
public class A51 {

    static private String X, Y, Z;

    public static void main(String[] args) {
        try {
            // Get parameters from the user
            X = getUserInput("X");
            Y = getUserInput("Y");
            Z = getUserInput("Z");
            int n = Integer.parseInt(getUserInput("number of bits to generate"));
            // Print the result
            System.out.print("Generated: ");
            for (int i = 0; i < n; i++)
                System.out.print(generate());
            System.out.println();
            System.out.println("Current X: " + X);
            System.out.println("Current Y: " + Y);
            System.out.println("Current Z: " + Z);
        } catch (Exception e) {
            System.out.println("Something wrong: " + e.getMessage());
        }
    }

    /**
     * Generate 1 bit.
     *
     * @return 1 bit (0 or 1)
     */
    static private int generate() {
        // Compute majority
        int x_8 = get(X, 8);
        int y_10 = get(Y, 10);
        int z_10 = get(Z, 10);
        int maj = (x_8 + y_10 + z_10) >= 2 ? 1 : 0;
        // Step based on majority
        if (x_8 == maj) X = step(X, 13, 16, 17, 18);
        if (y_10 == maj) Y = step(Y, 20, 21);
        if (z_10 == maj) Z = step(Z, 7, 20, 21, 22);
        // XOR the last bit
        return get(X, 18) ^ get(Y, 21) ^ get(Z, 22);
    }

    /**
     * Step the register.
     *
     * @param register the register to step
     * @param taps     indexes of the bits used to generate the new leftmost bit
     */
    static private String step(String register, int... taps) {
        // XOR taps
        // Or can use sum(bits) % 2 for XOR
        int p = 0;
        for (int tap : taps)
            p ^= get(register, tap);
        // Shift all element to right by 1 means the rightmost bit is shifted off
        register = register.substring(0, register.length() - 1);
        // Set new leftmost bit
        return p + register;
    }

    /**
     * Get parameter from the user.
     *
     * @param param parameter needed
     * @return user input in String
     */
    static private String getUserInput(String param) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("Enter %s: ", param);
        return scanner.nextLine();
    }

    /**
     * Get one bit from the input string based on index n.
     *
     * @param input input string
     * @param n     index of the bit
     * @return Bit in int based on the index
     */
    static private int get(String input, int n) {
        // Or can use Character.getNumericValue
        return input.charAt(n) - '0';
    }
}